-- ============================================================================
-- SaaS CONTAS A RECEBER - SCHEMA COMPLETO PARA SUPABASE (PostgreSQL)
-- ============================================================================
-- Versão: 1.1 (Corrigida)
-- Data: 2026-02-04
-- Descrição: Schema corrigido para compatibilidade total com Supabase e TypeScript
-- ============================================================================

-- ============================================================================
-- 1. EXTENSÕES NECESSÁRIAS
-- ============================================================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================================
-- 2. TIPOS ENUMERADOS
-- ============================================================================

-- Status de faturamento
DO $$ BEGIN
    CREATE TYPE faturamento_status AS ENUM ('pendente', 'parcial', 'pago', 'vencido', 'cancelado');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Tipo de parcela
DO $$ BEGIN
    CREATE TYPE tipo_parcela AS ENUM ('unica', 'parcelado', 'recorrente');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Status de parcela
DO $$ BEGIN
    CREATE TYPE parcela_status AS ENUM ('pendente', 'pago', 'vencido', 'cancelada');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Canais de cobrança
DO $$ BEGIN
    CREATE TYPE canal_cobranca AS ENUM ('email', 'whatsapp', 'sms', 'pix');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Status de cobrança
DO $$ BEGIN
    CREATE TYPE status_cobranca AS ENUM ('pendente', 'enviada', 'recebida', 'lida', 'paga', 'cancelada');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Status de envio de email
DO $$ BEGIN
    CREATE TYPE status_envio_email AS ENUM ('enviado', 'falha', 'bounce', 'recebido', 'lido');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Status de conciliação
DO $$ BEGIN
    CREATE TYPE status_conciliacao AS ENUM ('pendente', 'confirmada', 'rejeitada');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- ============================================================================
-- 3. TABELAS PRINCIPAIS
-- ============================================================================

-- Tabela de Usuários
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  open_id VARCHAR(64) UNIQUE NOT NULL,
  name TEXT,
  email VARCHAR(320),
  login_method VARCHAR(64),
  role VARCHAR(50) DEFAULT 'user' NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  last_signed_in TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Tabela de Serviços
CREATE TABLE IF NOT EXISTS servicos (
  id SERIAL PRIMARY KEY,
  descricao VARCHAR(255) NOT NULL,
  valor VARCHAR(20) NOT NULL,
  ativo INTEGER DEFAULT 1,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Tabela de Clientes
CREATE TABLE IF NOT EXISTS clientes (
  id SERIAL PRIMARY KEY,
  nome_completo VARCHAR(255) NOT NULL,
  email VARCHAR(320) NOT NULL,
  cpf_cnpj VARCHAR(18) UNIQUE NOT NULL,
  telefone VARCHAR(20),
  endereco TEXT,
  cep VARCHAR(10),
  cidade VARCHAR(100),
  estado VARCHAR(2),
  formas_faturamento TEXT,
  ativo INTEGER DEFAULT 1,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Tabela de Faturamentos
CREATE TABLE IF NOT EXISTS faturamentos (
  id SERIAL PRIMARY KEY,
  cliente_id INTEGER NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
  numero VARCHAR(50) UNIQUE NOT NULL,
  descricao TEXT,
  data_emissao TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  data_vencimento TIMESTAMP WITH TIME ZONE NOT NULL,
  valor_total VARCHAR(20) NOT NULL,
  status faturamento_status DEFAULT 'pendente',
  tipo_parcela tipo_parcela DEFAULT 'unica',
  quantidade_parcelas INTEGER DEFAULT 1,
  juros_ao_mes VARCHAR(10),
  desconto VARCHAR(20),
  observacoes TEXT,
  ativo INTEGER DEFAULT 1,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Tabela de Parcelas
CREATE TABLE IF NOT EXISTS parcelas (
  id SERIAL PRIMARY KEY,
  faturamento_id INTEGER NOT NULL REFERENCES faturamentos(id) ON DELETE CASCADE,
  numero_parcela INTEGER NOT NULL,
  data_vencimento TIMESTAMP WITH TIME ZONE NOT NULL,
  valor VARCHAR(20) NOT NULL,
  juros VARCHAR(20) DEFAULT '0',
  multa VARCHAR(20) DEFAULT '0',
  desconto VARCHAR(20) DEFAULT '0',
  valor_pago VARCHAR(20) DEFAULT '0',
  data_pagamento TIMESTAMP WITH TIME ZONE,
  forma_pagamento VARCHAR(50),
  status parcela_status DEFAULT 'pendente',
  chave_pix VARCHAR(255),
  codigo_barras VARCHAR(50),
  ativo INTEGER DEFAULT 1,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Tabela de Itens de Faturamento
CREATE TABLE IF NOT EXISTS itens_faturamento (
  id SERIAL PRIMARY KEY,
  faturamento_id INTEGER NOT NULL REFERENCES faturamentos(id) ON DELETE CASCADE,
  descricao VARCHAR(255) NOT NULL,
  quantidade VARCHAR(20) NOT NULL,
  valor_unitario VARCHAR(20) NOT NULL,
  valor_total VARCHAR(20) NOT NULL,
  ativo INTEGER DEFAULT 1,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Tabela de Cobranças
CREATE TABLE IF NOT EXISTS cobrancas (
  id SERIAL PRIMARY KEY,
  parcela_id INTEGER NOT NULL REFERENCES parcelas(id) ON DELETE CASCADE,
  faturamento_id INTEGER NOT NULL REFERENCES faturamentos(id) ON DELETE CASCADE,
  cliente_id INTEGER NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
  status status_cobranca DEFAULT 'pendente',
  data_envio TIMESTAMP WITH TIME ZONE,
  data_recebimento TIMESTAMP WITH TIME ZONE,
  data_leitura TIMESTAMP WITH TIME ZONE,
  canal canal_cobranca DEFAULT 'email',
  tentativas INTEGER DEFAULT 0,
  proxima_tentativa TIMESTAMP WITH TIME ZONE,
  observacoes TEXT,
  ativo INTEGER DEFAULT 1,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Tabela de Logs de Email
CREATE TABLE IF NOT EXISTS logs_email (
  id SERIAL PRIMARY KEY,
  cobranca_id INTEGER REFERENCES cobrancas(id) ON DELETE SET NULL,
  faturamento_id INTEGER REFERENCES faturamentos(id) ON DELETE SET NULL,
  parcela_id INTEGER REFERENCES parcelas(id) ON DELETE SET NULL,
  cliente_id INTEGER REFERENCES clientes(id) ON DELETE SET NULL,
  email_destino VARCHAR(320) NOT NULL,
  assunto VARCHAR(255) NOT NULL,
  corpo TEXT,
  status status_envio_email DEFAULT 'enviado',
  mensagem_erro TEXT,
  data_envio TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  data_recebimento TIMESTAMP WITH TIME ZONE,
  data_leitura TIMESTAMP WITH TIME ZONE,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Tabela de Conciliação de Pagamentos
CREATE TABLE IF NOT EXISTS conciliacao (
  id SERIAL PRIMARY KEY,
  parcela_id INTEGER NOT NULL REFERENCES parcelas(id) ON DELETE CASCADE,
  faturamento_id INTEGER NOT NULL REFERENCES faturamentos(id) ON DELETE CASCADE,
  cliente_id INTEGER NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
  valor VARCHAR(20) NOT NULL,
  data_recebimento TIMESTAMP WITH TIME ZONE NOT NULL,
  forma_pagamento VARCHAR(50) NOT NULL,
  referencia VARCHAR(255),
  descricao TEXT,
  status status_conciliacao DEFAULT 'pendente',
  observacoes TEXT,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Tabela de Histórico de Pagamentos
CREATE TABLE IF NOT EXISTS historico_pagamentos (
  id SERIAL PRIMARY KEY,
  parcela_id INTEGER NOT NULL REFERENCES parcelas(id) ON DELETE CASCADE,
  faturamento_id INTEGER NOT NULL REFERENCES faturamentos(id) ON DELETE CASCADE,
  cliente_id INTEGER NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
  valor_pago VARCHAR(20) NOT NULL,
  data_pagamento TIMESTAMP WITH TIME ZONE NOT NULL,
  forma_pagamento VARCHAR(50) NOT NULL,
  referencia VARCHAR(255),
  juros_aplicados VARCHAR(20) DEFAULT '0',
  multa_aplicada VARCHAR(20) DEFAULT '0',
  desconto_aplicado VARCHAR(20) DEFAULT '0',
  observacoes TEXT,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ============================================================================
-- 4. ÍNDICES PARA PERFORMANCE
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_users_open_id ON users(open_id);
CREATE INDEX IF NOT EXISTS idx_clientes_cpf_cnpj ON clientes(cpf_cnpj);
CREATE INDEX IF NOT EXISTS idx_faturamentos_numero ON faturamentos(numero);
CREATE INDEX IF NOT EXISTS idx_parcelas_faturamento_id ON parcelas(faturamento_id);
CREATE INDEX IF NOT EXISTS idx_cobrancas_parcela_id ON cobrancas(parcela_id);

-- ============================================================================
-- 5. FUNÇÕES E TRIGGERS PARA UPDATED_AT
-- ============================================================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Aplicar a todas as tabelas que possuem updated_at ou atualizado_em
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_servicos_updated_at BEFORE UPDATE ON servicos FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_clientes_updated_at BEFORE UPDATE ON clientes FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_faturamentos_updated_at BEFORE UPDATE ON faturamentos FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_parcelas_updated_at BEFORE UPDATE ON parcelas FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_itens_faturamento_updated_at BEFORE UPDATE ON itens_faturamento FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_cobrancas_updated_at BEFORE UPDATE ON cobrancas FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_conciliacao_updated_at BEFORE UPDATE ON conciliacao FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

-- ============================================================================
-- 6. ROW LEVEL SECURITY (RLS) - OPCIONAL PARA SUPABASE
-- ============================================================================
-- Por padrão, o Supabase habilita RLS. Se desejar usar, descomente abaixo.
-- ALTER TABLE users ENABLE ROW LEVEL SECURITY;
-- ... adicionar políticas conforme necessário ...

-- ============================================================================
-- FIM DO SCHEMA CORRIGIDO
-- ============================================================================
