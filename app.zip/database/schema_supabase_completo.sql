-- ============================================================================
-- SaaS CONTAS A RECEBER - SCHEMA COMPLETO PARA SUPABASE (PostgreSQL)
-- ============================================================================
-- Versão: 2.0 (Otimizado para Deploy)
-- Data: 2026-02-04
-- Descrição: Schema completo com segurança, índices e permissões
-- ============================================================================

-- ============================================================================
-- 1. EXTENSÕES NECESSÁRIAS
-- ============================================================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================================
-- 2. TIPOS ENUMERADOS
-- ============================================================================

-- Status de faturamento
DO $$ BEGIN
    CREATE TYPE faturamento_status AS ENUM ('pendente', 'parcial', 'pago', 'vencido', 'cancelado');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Tipo de parcela
DO $$ BEGIN
    CREATE TYPE tipo_parcela AS ENUM ('unica', 'parcelado', 'recorrente');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Status de parcela
DO $$ BEGIN
    CREATE TYPE parcela_status AS ENUM ('pendente', 'pago', 'vencido', 'cancelada');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Canais de cobrança
DO $$ BEGIN
    CREATE TYPE canal_cobranca AS ENUM ('email', 'whatsapp', 'sms', 'pix');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Status de cobrança
DO $$ BEGIN
    CREATE TYPE status_cobranca AS ENUM ('pendente', 'enviada', 'recebida', 'lida', 'paga', 'cancelada');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Status de envio de email
DO $$ BEGIN
    CREATE TYPE status_envio_email AS ENUM ('enviado', 'falha', 'bounce', 'recebido', 'lido');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Status de conciliação
DO $$ BEGIN
    CREATE TYPE status_conciliacao AS ENUM ('pendente', 'confirmada', 'rejeitada');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- ============================================================================
-- 3. LIMPAR TABELAS EXISTENTES (SE NECESSÁRIO)
-- ============================================================================
-- ATENÇÃO: Isso apagará todos os dados! Comente se já tiver dados importantes.

-- DROP TABLE IF EXISTS historico_pagamentos CASCADE;
-- DROP TABLE IF EXISTS conciliacao CASCADE;
-- DROP TABLE IF EXISTS logs_email CASCADE;
-- DROP TABLE IF EXISTS cobrancas CASCADE;
-- DROP TABLE IF EXISTS itens_faturamento CASCADE;
-- DROP TABLE IF EXISTS parcelas CASCADE;
-- DROP TABLE IF EXISTS faturamentos CASCADE;
-- DROP TABLE IF EXISTS clientes CASCADE;
-- DROP TABLE IF EXISTS servicos CASCADE;
-- DROP TABLE IF EXISTS users CASCADE;

-- ============================================================================
-- 4. TABELAS PRINCIPAIS
-- ============================================================================

-- Tabela de Usuários
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  open_id VARCHAR(64) UNIQUE NOT NULL,
  name TEXT,
  email VARCHAR(320),
  login_method VARCHAR(64),
  role VARCHAR(50) DEFAULT 'user' NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  last_signed_in TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

COMMENT ON TABLE users IS 'Tabela de usuários do sistema com autenticação OAuth';
COMMENT ON COLUMN users.open_id IS 'ID único do OAuth provider';
COMMENT ON COLUMN users.role IS 'Papel do usuário: user, admin, etc';

-- Tabela de Serviços
CREATE TABLE IF NOT EXISTS servicos (
  id SERIAL PRIMARY KEY,
  descricao VARCHAR(255) NOT NULL,
  valor VARCHAR(20) NOT NULL,
  ativo INTEGER DEFAULT 1,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

COMMENT ON TABLE servicos IS 'Catálogo de serviços disponíveis para faturamento';
COMMENT ON COLUMN servicos.valor IS 'Valor armazenado como string para precisão decimal';
COMMENT ON COLUMN servicos.ativo IS 'Flag de ativação: 1=ativo, 0=inativo';

-- Tabela de Clientes
CREATE TABLE IF NOT EXISTS clientes (
  id SERIAL PRIMARY KEY,
  nome_completo VARCHAR(255) NOT NULL,
  email VARCHAR(320) NOT NULL,
  cpf_cnpj VARCHAR(18) UNIQUE NOT NULL,
  telefone VARCHAR(20),
  endereco TEXT,
  cep VARCHAR(10),
  cidade VARCHAR(100),
  estado VARCHAR(2),
  formas_faturamento TEXT,
  ativo INTEGER DEFAULT 1,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

COMMENT ON TABLE clientes IS 'Cadastro de clientes pessoa física e jurídica';
COMMENT ON COLUMN clientes.cpf_cnpj IS 'CPF ou CNPJ - campo único';
COMMENT ON COLUMN clientes.formas_faturamento IS 'JSON com formas de faturamento preferidas';

-- Tabela de Faturamentos
CREATE TABLE IF NOT EXISTS faturamentos (
  id SERIAL PRIMARY KEY,
  cliente_id INTEGER NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
  numero VARCHAR(50) UNIQUE NOT NULL,
  descricao TEXT,
  data_emissao TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  data_vencimento TIMESTAMP WITH TIME ZONE NOT NULL,
  valor_total VARCHAR(20) NOT NULL,
  status faturamento_status DEFAULT 'pendente',
  tipo_parcela tipo_parcela DEFAULT 'unica',
  quantidade_parcelas INTEGER DEFAULT 1,
  juros_ao_mes VARCHAR(10),
  desconto VARCHAR(20),
  observacoes TEXT,
  ativo INTEGER DEFAULT 1,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

COMMENT ON TABLE faturamentos IS 'Faturamentos emitidos para clientes';
COMMENT ON COLUMN faturamentos.numero IS 'Número único do faturamento';
COMMENT ON COLUMN faturamentos.status IS 'pendente, parcial, pago, vencido, cancelado';
COMMENT ON COLUMN faturamentos.tipo_parcela IS 'unica, parcelado, recorrente';

-- Tabela de Parcelas
CREATE TABLE IF NOT EXISTS parcelas (
  id SERIAL PRIMARY KEY,
  faturamento_id INTEGER NOT NULL REFERENCES faturamentos(id) ON DELETE CASCADE,
  numero_parcela INTEGER NOT NULL,
  data_vencimento TIMESTAMP WITH TIME ZONE NOT NULL,
  valor VARCHAR(20) NOT NULL,
  juros VARCHAR(20) DEFAULT '0',
  multa VARCHAR(20) DEFAULT '0',
  desconto VARCHAR(20) DEFAULT '0',
  valor_pago VARCHAR(20) DEFAULT '0',
  data_pagamento TIMESTAMP WITH TIME ZONE,
  forma_pagamento VARCHAR(50),
  status parcela_status DEFAULT 'pendente',
  chave_pix VARCHAR(255),
  codigo_barras VARCHAR(50),
  ativo INTEGER DEFAULT 1,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  CONSTRAINT parcelas_numero_faturamento_unique UNIQUE(faturamento_id, numero_parcela)
);

COMMENT ON TABLE parcelas IS 'Parcelas individuais de cada faturamento';
COMMENT ON COLUMN parcelas.status IS 'pendente, pago, vencido, cancelada';

-- Tabela de Itens de Faturamento
CREATE TABLE IF NOT EXISTS itens_faturamento (
  id SERIAL PRIMARY KEY,
  faturamento_id INTEGER NOT NULL REFERENCES faturamentos(id) ON DELETE CASCADE,
  descricao VARCHAR(255) NOT NULL,
  quantidade VARCHAR(20) NOT NULL,
  valor_unitario VARCHAR(20) NOT NULL,
  valor_total VARCHAR(20) NOT NULL,
  ativo INTEGER DEFAULT 1,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

COMMENT ON TABLE itens_faturamento IS 'Itens detalhados de cada faturamento';

-- Tabela de Cobranças
CREATE TABLE IF NOT EXISTS cobrancas (
  id SERIAL PRIMARY KEY,
  parcela_id INTEGER NOT NULL REFERENCES parcelas(id) ON DELETE CASCADE,
  faturamento_id INTEGER NOT NULL REFERENCES faturamentos(id) ON DELETE CASCADE,
  cliente_id INTEGER NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
  status status_cobranca DEFAULT 'pendente',
  data_envio TIMESTAMP WITH TIME ZONE,
  data_recebimento TIMESTAMP WITH TIME ZONE,
  data_leitura TIMESTAMP WITH TIME ZONE,
  canal canal_cobranca DEFAULT 'email',
  tentativas INTEGER DEFAULT 0,
  proxima_tentativa TIMESTAMP WITH TIME ZONE,
  observacoes TEXT,
  ativo INTEGER DEFAULT 1,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

COMMENT ON TABLE cobrancas IS 'Controle de cobranças e lembretes enviados';
COMMENT ON COLUMN cobrancas.canal IS 'email, whatsapp, sms, pix';
COMMENT ON COLUMN cobrancas.status IS 'pendente, enviada, recebida, lida, paga, cancelada';

-- Tabela de Logs de Email
CREATE TABLE IF NOT EXISTS logs_email (
  id SERIAL PRIMARY KEY,
  cobranca_id INTEGER REFERENCES cobrancas(id) ON DELETE SET NULL,
  faturamento_id INTEGER REFERENCES faturamentos(id) ON DELETE SET NULL,
  parcela_id INTEGER REFERENCES parcelas(id) ON DELETE SET NULL,
  cliente_id INTEGER REFERENCES clientes(id) ON DELETE SET NULL,
  email_destino VARCHAR(320) NOT NULL,
  assunto VARCHAR(255) NOT NULL,
  corpo TEXT,
  status status_envio_email DEFAULT 'enviado',
  mensagem_erro TEXT,
  data_envio TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  data_recebimento TIMESTAMP WITH TIME ZONE,
  data_leitura TIMESTAMP WITH TIME ZONE,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

COMMENT ON TABLE logs_email IS 'Log de todos os emails enviados pelo sistema';

-- Tabela de Conciliação de Pagamentos
CREATE TABLE IF NOT EXISTS conciliacao (
  id SERIAL PRIMARY KEY,
  parcela_id INTEGER NOT NULL REFERENCES parcelas(id) ON DELETE CASCADE,
  faturamento_id INTEGER NOT NULL REFERENCES faturamentos(id) ON DELETE CASCADE,
  cliente_id INTEGER NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
  valor VARCHAR(20) NOT NULL,
  data_recebimento TIMESTAMP WITH TIME ZONE NOT NULL,
  forma_pagamento VARCHAR(50) NOT NULL,
  referencia VARCHAR(255),
  descricao TEXT,
  status status_conciliacao DEFAULT 'pendente',
  observacoes TEXT,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
  atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

COMMENT ON TABLE conciliacao IS 'Conciliação bancária de pagamentos recebidos';

-- Tabela de Histórico de Pagamentos
CREATE TABLE IF NOT EXISTS historico_pagamentos (
  id SERIAL PRIMARY KEY,
  parcela_id INTEGER NOT NULL REFERENCES parcelas(id) ON DELETE CASCADE,
  faturamento_id INTEGER NOT NULL REFERENCES faturamentos(id) ON DELETE CASCADE,
  cliente_id INTEGER NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
  valor_pago VARCHAR(20) NOT NULL,
  data_pagamento TIMESTAMP WITH TIME ZONE NOT NULL,
  forma_pagamento VARCHAR(50) NOT NULL,
  referencia VARCHAR(255),
  juros_aplicados VARCHAR(20) DEFAULT '0',
  multa_aplicada VARCHAR(20) DEFAULT '0',
  desconto_aplicado VARCHAR(20) DEFAULT '0',
  observacoes TEXT,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

COMMENT ON TABLE historico_pagamentos IS 'Histórico completo de todos os pagamentos recebidos';

-- ============================================================================
-- 5. ÍNDICES PARA PERFORMANCE
-- ============================================================================

-- Users
CREATE INDEX IF NOT EXISTS idx_users_open_id ON users(open_id);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

-- Clientes
CREATE INDEX IF NOT EXISTS idx_clientes_cpf_cnpj ON clientes(cpf_cnpj);
CREATE INDEX IF NOT EXISTS idx_clientes_email ON clientes(email);
CREATE INDEX IF NOT EXISTS idx_clientes_ativo ON clientes(ativo);

-- Faturamentos
CREATE INDEX IF NOT EXISTS idx_faturamentos_numero ON faturamentos(numero);
CREATE INDEX IF NOT EXISTS idx_faturamentos_cliente_id ON faturamentos(cliente_id);
CREATE INDEX IF NOT EXISTS idx_faturamentos_status ON faturamentos(status);
CREATE INDEX IF NOT EXISTS idx_faturamentos_data_vencimento ON faturamentos(data_vencimento);
CREATE INDEX IF NOT EXISTS idx_faturamentos_ativo ON faturamentos(ativo);

-- Parcelas
CREATE INDEX IF NOT EXISTS idx_parcelas_faturamento_id ON parcelas(faturamento_id);
CREATE INDEX IF NOT EXISTS idx_parcelas_status ON parcelas(status);
CREATE INDEX IF NOT EXISTS idx_parcelas_data_vencimento ON parcelas(data_vencimento);
CREATE INDEX IF NOT EXISTS idx_parcelas_ativo ON parcelas(ativo);

-- Itens Faturamento
CREATE INDEX IF NOT EXISTS idx_itens_faturamento_faturamento_id ON itens_faturamento(faturamento_id);

-- Cobranças
CREATE INDEX IF NOT EXISTS idx_cobrancas_parcela_id ON cobrancas(parcela_id);
CREATE INDEX IF NOT EXISTS idx_cobrancas_faturamento_id ON cobrancas(faturamento_id);
CREATE INDEX IF NOT EXISTS idx_cobrancas_cliente_id ON cobrancas(cliente_id);
CREATE INDEX IF NOT EXISTS idx_cobrancas_status ON cobrancas(status);
CREATE INDEX IF NOT EXISTS idx_cobrancas_canal ON cobrancas(canal);
CREATE INDEX IF NOT EXISTS idx_cobrancas_proxima_tentativa ON cobrancas(proxima_tentativa);

-- Logs Email
CREATE INDEX IF NOT EXISTS idx_logs_email_cobranca_id ON logs_email(cobranca_id);
CREATE INDEX IF NOT EXISTS idx_logs_email_cliente_id ON logs_email(cliente_id);
CREATE INDEX IF NOT EXISTS idx_logs_email_status ON logs_email(status);
CREATE INDEX IF NOT EXISTS idx_logs_email_data_envio ON logs_email(data_envio);

-- Conciliação
CREATE INDEX IF NOT EXISTS idx_conciliacao_parcela_id ON conciliacao(parcela_id);
CREATE INDEX IF NOT EXISTS idx_conciliacao_faturamento_id ON conciliacao(faturamento_id);
CREATE INDEX IF NOT EXISTS idx_conciliacao_cliente_id ON conciliacao(cliente_id);
CREATE INDEX IF NOT EXISTS idx_conciliacao_status ON conciliacao(status);

-- Histórico Pagamentos
CREATE INDEX IF NOT EXISTS idx_historico_pagamentos_parcela_id ON historico_pagamentos(parcela_id);
CREATE INDEX IF NOT EXISTS idx_historico_pagamentos_cliente_id ON historico_pagamentos(cliente_id);
CREATE INDEX IF NOT EXISTS idx_historico_pagamentos_data_pagamento ON historico_pagamentos(data_pagamento);

-- ============================================================================
-- 6. FUNÇÕES E TRIGGERS PARA UPDATED_AT
-- ============================================================================

-- Função para atualizar automaticamente o campo updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Função para atualizar atualizado_em
CREATE OR REPLACE FUNCTION update_atualizado_em_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.atualizado_em = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Aplicar triggers nas tabelas com updated_at
DO $$ 
BEGIN
    -- Users
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_users_updated_at') THEN
        CREATE TRIGGER update_users_updated_at 
        BEFORE UPDATE ON users 
        FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;

    -- Servicos
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_servicos_atualizado_em') THEN
        CREATE TRIGGER update_servicos_atualizado_em 
        BEFORE UPDATE ON servicos 
        FOR EACH ROW EXECUTE FUNCTION update_atualizado_em_column();
    END IF;

    -- Clientes
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_clientes_atualizado_em') THEN
        CREATE TRIGGER update_clientes_atualizado_em 
        BEFORE UPDATE ON clientes 
        FOR EACH ROW EXECUTE FUNCTION update_atualizado_em_column();
    END IF;

    -- Faturamentos
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_faturamentos_atualizado_em') THEN
        CREATE TRIGGER update_faturamentos_atualizado_em 
        BEFORE UPDATE ON faturamentos 
        FOR EACH ROW EXECUTE FUNCTION update_atualizado_em_column();
    END IF;

    -- Parcelas
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_parcelas_atualizado_em') THEN
        CREATE TRIGGER update_parcelas_atualizado_em 
        BEFORE UPDATE ON parcelas 
        FOR EACH ROW EXECUTE FUNCTION update_atualizado_em_column();
    END IF;

    -- Itens Faturamento
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_itens_faturamento_atualizado_em') THEN
        CREATE TRIGGER update_itens_faturamento_atualizado_em 
        BEFORE UPDATE ON itens_faturamento 
        FOR EACH ROW EXECUTE FUNCTION update_atualizado_em_column();
    END IF;

    -- Cobranças
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_cobrancas_atualizado_em') THEN
        CREATE TRIGGER update_cobrancas_atualizado_em 
        BEFORE UPDATE ON cobrancas 
        FOR EACH ROW EXECUTE FUNCTION update_atualizado_em_column();
    END IF;

    -- Conciliação
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_conciliacao_atualizado_em') THEN
        CREATE TRIGGER update_conciliacao_atualizado_em 
        BEFORE UPDATE ON conciliacao 
        FOR EACH ROW EXECUTE FUNCTION update_atualizado_em_column();
    END IF;
END $$;

-- ============================================================================
-- 7. FUNÇÃO PARA ATUALIZAR STATUS DE FATURAMENTO
-- ============================================================================

-- Função para atualizar o status do faturamento com base nas parcelas
CREATE OR REPLACE FUNCTION update_faturamento_status()
RETURNS TRIGGER AS $$
DECLARE
    total_parcelas INTEGER;
    parcelas_pagas INTEGER;
    parcelas_pendentes INTEGER;
    parcelas_vencidas INTEGER;
BEGIN
    -- Contar parcelas por status
    SELECT 
        COUNT(*),
        COUNT(*) FILTER (WHERE status = 'pago'),
        COUNT(*) FILTER (WHERE status = 'pendente'),
        COUNT(*) FILTER (WHERE status = 'vencido')
    INTO total_parcelas, parcelas_pagas, parcelas_pendentes, parcelas_vencidas
    FROM parcelas
    WHERE faturamento_id = COALESCE(NEW.faturamento_id, OLD.faturamento_id)
    AND ativo = 1;

    -- Atualizar status do faturamento
    IF parcelas_pagas = total_parcelas THEN
        UPDATE faturamentos SET status = 'pago' WHERE id = COALESCE(NEW.faturamento_id, OLD.faturamento_id);
    ELSIF parcelas_pagas > 0 THEN
        UPDATE faturamentos SET status = 'parcial' WHERE id = COALESCE(NEW.faturamento_id, OLD.faturamento_id);
    ELSIF parcelas_vencidas > 0 THEN
        UPDATE faturamentos SET status = 'vencido' WHERE id = COALESCE(NEW.faturamento_id, OLD.faturamento_id);
    ELSE
        UPDATE faturamentos SET status = 'pendente' WHERE id = COALESCE(NEW.faturamento_id, OLD.faturamento_id);
    END IF;

    RETURN COALESCE(NEW, OLD);
END;
$$ language 'plpgsql';

-- Aplicar trigger
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trigger_update_faturamento_status') THEN
        CREATE TRIGGER trigger_update_faturamento_status
        AFTER INSERT OR UPDATE ON parcelas
        FOR EACH ROW EXECUTE FUNCTION update_faturamento_status();
    END IF;
END $$;

-- ============================================================================
-- 8. VIEWS ÚTEIS PARA RELATÓRIOS
-- ============================================================================

-- View: Faturamentos com dados do cliente
CREATE OR REPLACE VIEW v_faturamentos_completos AS
SELECT 
    f.*,
    c.nome_completo as cliente_nome,
    c.email as cliente_email,
    c.cpf_cnpj as cliente_cpf_cnpj,
    c.telefone as cliente_telefone,
    COUNT(p.id) as total_parcelas,
    COUNT(p.id) FILTER (WHERE p.status = 'pago') as parcelas_pagas,
    COUNT(p.id) FILTER (WHERE p.status = 'pendente') as parcelas_pendentes,
    COUNT(p.id) FILTER (WHERE p.status = 'vencido') as parcelas_vencidas
FROM faturamentos f
INNER JOIN clientes c ON f.cliente_id = c.id
LEFT JOIN parcelas p ON f.id = p.faturamento_id AND p.ativo = 1
WHERE f.ativo = 1
GROUP BY f.id, c.id;

-- View: Parcelas a vencer nos próximos dias
CREATE OR REPLACE VIEW v_parcelas_proximas_vencimento AS
SELECT 
    p.*,
    f.numero as faturamento_numero,
    f.descricao as faturamento_descricao,
    c.nome_completo as cliente_nome,
    c.email as cliente_email,
    c.telefone as cliente_telefone,
    (p.data_vencimento - CURRENT_TIMESTAMP) as tempo_ate_vencimento
FROM parcelas p
INNER JOIN faturamentos f ON p.faturamento_id = f.id
INNER JOIN clientes c ON f.cliente_id = c.id
WHERE p.status = 'pendente'
AND p.ativo = 1
AND p.data_vencimento <= CURRENT_TIMESTAMP + INTERVAL '7 days'
ORDER BY p.data_vencimento ASC;

-- View: Dashboard financeiro
CREATE OR REPLACE VIEW v_dashboard_financeiro AS
SELECT 
    COUNT(DISTINCT f.id) as total_faturamentos,
    COUNT(DISTINCT CASE WHEN f.status = 'pendente' THEN f.id END) as faturamentos_pendentes,
    COUNT(DISTINCT CASE WHEN f.status = 'pago' THEN f.id END) as faturamentos_pagos,
    COUNT(DISTINCT CASE WHEN f.status = 'vencido' THEN f.id END) as faturamentos_vencidos,
    COUNT(p.id) as total_parcelas,
    COUNT(CASE WHEN p.status = 'pendente' THEN 1 END) as parcelas_pendentes,
    COUNT(CASE WHEN p.status = 'pago' THEN 1 END) as parcelas_pagas,
    COUNT(CASE WHEN p.status = 'vencido' THEN 1 END) as parcelas_vencidas,
    SUM(CASE WHEN p.status = 'pago' THEN p.valor_pago::DECIMAL ELSE 0 END) as valor_total_recebido,
    SUM(CASE WHEN p.status = 'pendente' THEN p.valor::DECIMAL ELSE 0 END) as valor_total_pendente,
    SUM(CASE WHEN p.status = 'vencido' THEN p.valor::DECIMAL ELSE 0 END) as valor_total_vencido
FROM faturamentos f
LEFT JOIN parcelas p ON f.id = p.faturamento_id AND p.ativo = 1
WHERE f.ativo = 1;

-- ============================================================================
-- 9. PERMISSÕES (Row Level Security - RLS)
-- ============================================================================

-- Desabilitar RLS por padrão (ative conforme necessidade)
-- ALTER TABLE users ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE faturamentos ENABLE ROW LEVEL SECURITY;

-- Exemplo de política RLS (descomente para usar)
-- CREATE POLICY "Users can view their own data" ON users
--   FOR SELECT USING (auth.uid() = id);

-- ============================================================================
-- 10. DADOS INICIAIS (SEED DATA)
-- ============================================================================

-- Inserir usuário administrador padrão (opcional)
-- INSERT INTO users (open_id, name, email, role) 
-- VALUES ('admin', 'Administrador', 'admin@example.com', 'admin')
-- ON CONFLICT (open_id) DO NOTHING;

-- ============================================================================
-- 11. FUNÇÕES AUXILIARES
-- ============================================================================

-- Função para calcular juros e multa
CREATE OR REPLACE FUNCTION calcular_juros_multa(
    p_valor DECIMAL,
    p_juros_mes DECIMAL,
    p_multa DECIMAL,
    p_dias_atraso INTEGER
) RETURNS TABLE(juros DECIMAL, multa DECIMAL, valor_total DECIMAL) AS $$
BEGIN
    RETURN QUERY SELECT 
        (p_valor * p_juros_mes / 100 / 30 * p_dias_atraso)::DECIMAL as juros,
        (p_valor * p_multa / 100)::DECIMAL as multa,
        (p_valor + (p_valor * p_juros_mes / 100 / 30 * p_dias_atraso) + (p_valor * p_multa / 100))::DECIMAL as valor_total;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- 12. VERIFICAÇÃO FINAL
-- ============================================================================

-- Listar todas as tabelas criadas
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_type = 'BASE TABLE'
ORDER BY table_name;

-- Listar todos os índices
SELECT indexname, tablename 
FROM pg_indexes 
WHERE schemaname = 'public'
ORDER BY tablename, indexname;

-- Listar todos os tipos enumerados
SELECT t.typname as enum_name, e.enumlabel as enum_value
FROM pg_type t 
JOIN pg_enum e ON t.oid = e.enumtypid  
WHERE t.typname IN (
    'faturamento_status', 'tipo_parcela', 'parcela_status', 
    'canal_cobranca', 'status_cobranca', 'status_envio_email', 'status_conciliacao'
)
ORDER BY t.typname, e.enumsortorder;

-- ============================================================================
-- FIM DO SCHEMA COMPLETO
-- ============================================================================

-- IMPORTANTE: Execute este script no SQL Editor do Supabase
-- Após execução, configure o .env com a DATABASE_URL do seu projeto
