-- ============================================================================
-- SaaS CONTAS A RECEBER - SCHEMA COMPLETO PARA SUPABASE (PostgreSQL)
-- ============================================================================
-- Versão: 1.0
-- Data: 2026-02-04
-- Descrição: Schema completo com todas as funcionalidades de contas a receber
-- ============================================================================

-- ============================================================================
-- 1. EXTENSÕES NECESSÁRIAS
-- ============================================================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================================
-- 2. TIPOS ENUMERADOS
-- ============================================================================

-- Status de faturamento
CREATE TYPE faturamento_status AS ENUM (
  'rascunho',
  'emitido',
  'enviado',
  'pago',
  'vencido',
  'cancelado'
);

-- Tipo de pagamento
CREATE TYPE tipo_pagamento AS ENUM (
  'a_vista',
  'parcelado',
  'recorrente'
);

-- Status de parcela
CREATE TYPE parcela_status AS ENUM (
  'pendente',
  'enviada',
  'paga',
  'vencida',
  'cancelada'
);

-- Formas de cobrança
CREATE TYPE forma_cobranca AS ENUM (
  'pix',
  'boleto',
  'cartao'
);

-- Canais de cobrança
CREATE TYPE canal_cobranca AS ENUM (
  'email',
  'whatsapp',
  'sms'
);

-- Status de envio de email
CREATE TYPE status_envio_email AS ENUM (
  'pendente',
  'enviado',
  'recebido',
  'lido',
  'erro'
);

-- Status de conciliação
CREATE TYPE status_conciliacao AS ENUM (
  'pendente',
  'conciliado',
  'divergencia',
  'duplicado'
);

-- Frequência de cobrança
CREATE TYPE frequencia_cobranca AS ENUM (
  'diaria',
  'semanal',
  'quinzenal',
  'mensal',
  'customizada'
);

-- ============================================================================
-- 3. TABELAS PRINCIPAIS
-- ============================================================================

-- Tabela de Usuários (Tenants - Multi-tenancy)
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  open_id VARCHAR(255) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(255),
  login_method VARCHAR(100),
  role VARCHAR(50) DEFAULT 'user',
  two_fa_enabled BOOLEAN DEFAULT FALSE,
  two_fa_secret VARCHAR(255),
  last_login TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Empresas (Configurações por Tenant)
CREATE TABLE IF NOT EXISTS empresas (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL UNIQUE,
  nome VARCHAR(255) NOT NULL,
  cnpj VARCHAR(20) UNIQUE,
  email VARCHAR(255),
  telefone VARCHAR(20),
  endereco VARCHAR(255),
  numero VARCHAR(10),
  complemento VARCHAR(255),
  bairro VARCHAR(100),
  cidade VARCHAR(100),
  estado VARCHAR(2),
  cep VARCHAR(10),
  logo_url TEXT,
  website VARCHAR(255),
  inscricao_estadual VARCHAR(20),
  razao_social VARCHAR(255),
  nome_fantasia VARCHAR(255),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabela de Configurações SMTP
CREATE TABLE IF NOT EXISTS configuracoes_smtp (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL UNIQUE,
  host VARCHAR(255) NOT NULL,
  port INTEGER NOT NULL DEFAULT 587,
  usuario VARCHAR(255) NOT NULL,
  senha TEXT NOT NULL,
  de VARCHAR(255) NOT NULL,
  ativo BOOLEAN DEFAULT FALSE,
  testado_em TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabela de Configurações PIX
CREATE TABLE IF NOT EXISTS configuracoes_pix (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL UNIQUE,
  chave VARCHAR(255) NOT NULL,
  tipo_chave VARCHAR(50) NOT NULL,
  banco VARCHAR(100),
  agencia VARCHAR(20),
  conta VARCHAR(30),
  titular VARCHAR(255),
  ativo BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabela de Configurações WhatsApp
CREATE TABLE IF NOT EXISTS configuracoes_whatsapp (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL UNIQUE,
  token TEXT NOT NULL,
  numero_telefone VARCHAR(20) NOT NULL,
  ativo BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabela de Configurações SMS
CREATE TABLE IF NOT EXISTS configuracoes_sms (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL UNIQUE,
  api_key TEXT NOT NULL,
  api_url VARCHAR(255) NOT NULL,
  remetente VARCHAR(11) NOT NULL,
  ativo BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabela de Configurações de Boleto
CREATE TABLE IF NOT EXISTS configuracoes_boleto (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL UNIQUE,
  banco VARCHAR(100) NOT NULL,
  agencia VARCHAR(20) NOT NULL,
  conta VARCHAR(30) NOT NULL,
  digito_verificador VARCHAR(2),
  carteira VARCHAR(20),
  nosso_numero_inicio VARCHAR(20),
  ativo BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabela de Configurações de Cartão/Link de Pagamento
CREATE TABLE IF NOT EXISTS configuracoes_cartao (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL UNIQUE,
  provider VARCHAR(100) NOT NULL,
  api_key TEXT NOT NULL,
  api_secret TEXT NOT NULL,
  url_base VARCHAR(255),
  ativo BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabela de Configurações de Conta Bancária
CREATE TABLE IF NOT EXISTS configuracoes_banco (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL UNIQUE,
  banco VARCHAR(100) NOT NULL,
  agencia VARCHAR(20) NOT NULL,
  conta VARCHAR(30) NOT NULL,
  tipo_conta VARCHAR(20),
  titular VARCHAR(255),
  cpf_cnpj_titular VARCHAR(20),
  chave_pix VARCHAR(255),
  ativo BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabela de Configurações do Formulário de Cobrança
CREATE TABLE IF NOT EXISTS configuracoes_formulario_cobranca (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL UNIQUE,
  mensagem_padrao TEXT,
  incluir_ultima_parcela BOOLEAN DEFAULT TRUE,
  incluir_todos_debitos BOOLEAN DEFAULT FALSE,
  mostrar_historico BOOLEAN DEFAULT TRUE,
  permitir_negociacao BOOLEAN DEFAULT FALSE,
  dias_aviso_vencimento INTEGER DEFAULT 3,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabela de Serviços
CREATE TABLE IF NOT EXISTS servicos (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL,
  descricao VARCHAR(255) NOT NULL,
  valor DECIMAL(12, 2) NOT NULL,
  categoria VARCHAR(100),
  status VARCHAR(50) DEFAULT 'ativo',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabela de Clientes
CREATE TABLE IF NOT EXISTS clientes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL,
  nome VARCHAR(255) NOT NULL,
  cpf_cnpj VARCHAR(20) UNIQUE,
  email VARCHAR(255),
  telefone VARCHAR(20),
  endereco VARCHAR(255),
  numero VARCHAR(10),
  complemento VARCHAR(255),
  bairro VARCHAR(100),
  cidade VARCHAR(100),
  estado VARCHAR(2),
  cep VARCHAR(10),
  
  -- Configurações de Cobrança
  formas_cobranca forma_cobranca[] DEFAULT ARRAY['pix'::forma_cobranca],
  canais_cobranca canal_cobranca[] DEFAULT ARRAY['email'::canal_cobranca],
  mensagem_cobranca TEXT,
  frequencia_cobranca frequencia_cobranca DEFAULT 'mensal',
  dias_frequencia INTEGER DEFAULT 1,
  preferencia_pagamento forma_cobranca DEFAULT 'pix',
  
  -- Dados Bancários
  banco VARCHAR(100),
  agencia VARCHAR(20),
  conta VARCHAR(30),
  tipo_conta VARCHAR(20),
  titular_conta VARCHAR(150),
  cpf_cnpj_titular VARCHAR(20),
  
  -- Contatos
  contato_principal_nome VARCHAR(150),
  contato_principal_email VARCHAR(150),
  contato_principal_telefone VARCHAR(20),
  contato_cobranca_nome VARCHAR(150),
  contato_cobranca_email VARCHAR(150),
  contato_cobranca_telefone VARCHAR(20),
  preferencia_comunicacao canal_cobranca DEFAULT 'email',
  
  -- Dados Adicionais
  inscricao_estadual VARCHAR(20),
  razao_social VARCHAR(255),
  nome_fantasia VARCHAR(255),
  ativo BOOLEAN DEFAULT TRUE,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabela de Faturamentos
CREATE TABLE IF NOT EXISTS faturamentos (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL,
  cliente_id UUID NOT NULL,
  numero_faturamento VARCHAR(50) UNIQUE NOT NULL,
  
  -- Tipo de Pagamento
  tipo_pagamento tipo_pagamento DEFAULT 'a_vista',
  quantidade_parcelas INTEGER DEFAULT 1,
  frequencia_recorrencia frequencia_cobranca,
  proxima_cobranca DATE,
  
  -- Valores
  valor_total DECIMAL(12, 2) NOT NULL,
  desconto DECIMAL(12, 2) DEFAULT 0,
  juros DECIMAL(12, 2) DEFAULT 0,
  valor_liquido DECIMAL(12, 2) NOT NULL,
  
  -- Status
  status faturamento_status DEFAULT 'rascunho',
  data_emissao DATE DEFAULT CURRENT_DATE,
  data_vencimento DATE,
  
  -- Observações
  observacoes TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE RESTRICT
);

-- Tabela de Itens de Faturamento
CREATE TABLE IF NOT EXISTS itens_faturamento (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  faturamento_id UUID NOT NULL,
  servico_id UUID,
  descricao VARCHAR(255) NOT NULL,
  quantidade INTEGER DEFAULT 1,
  valor_unitario DECIMAL(12, 2) NOT NULL,
  valor_total DECIMAL(12, 2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (faturamento_id) REFERENCES faturamentos(id) ON DELETE CASCADE,
  FOREIGN KEY (servico_id) REFERENCES servicos(id) ON DELETE SET NULL
);

-- Tabela de Parcelas
CREATE TABLE IF NOT EXISTS parcelas (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  faturamento_id UUID NOT NULL,
  numero_parcela INTEGER NOT NULL,
  valor DECIMAL(12, 2) NOT NULL,
  data_vencimento DATE NOT NULL,
  status parcela_status DEFAULT 'pendente',
  data_pagamento DATE,
  valor_pago DECIMAL(12, 2),
  juros_atraso DECIMAL(12, 2) DEFAULT 0,
  multa_atraso DECIMAL(12, 2) DEFAULT 0,
  desconto_antecipado DECIMAL(12, 2) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (faturamento_id) REFERENCES faturamentos(id) ON DELETE CASCADE
);

-- Tabela de Log de Envios de Email
CREATE TABLE IF NOT EXISTS log_envios_email (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  faturamento_id UUID NOT NULL,
  parcela_id UUID,
  destinatario VARCHAR(255) NOT NULL,
  assunto VARCHAR(255),
  corpo_email TEXT,
  status status_envio_email DEFAULT 'pendente',
  enviado_em TIMESTAMP WITH TIME ZONE,
  recebido_em TIMESTAMP WITH TIME ZONE,
  lido_em TIMESTAMP WITH TIME ZONE,
  erro_mensagem TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (faturamento_id) REFERENCES faturamentos(id) ON DELETE CASCADE,
  FOREIGN KEY (parcela_id) REFERENCES parcelas(id) ON DELETE SET NULL
);

-- Tabela de Log de Envios WhatsApp
CREATE TABLE IF NOT EXISTS log_envios_whatsapp (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  faturamento_id UUID NOT NULL,
  parcela_id UUID,
  numero_telefone VARCHAR(20) NOT NULL,
  mensagem TEXT,
  status status_envio_email DEFAULT 'pendente',
  id_mensagem_externa VARCHAR(255),
  enviado_em TIMESTAMP WITH TIME ZONE,
  entregue_em TIMESTAMP WITH TIME ZONE,
  lido_em TIMESTAMP WITH TIME ZONE,
  erro_mensagem TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (faturamento_id) REFERENCES faturamentos(id) ON DELETE CASCADE,
  FOREIGN KEY (parcela_id) REFERENCES parcelas(id) ON DELETE SET NULL
);

-- Tabela de Log de Envios SMS
CREATE TABLE IF NOT EXISTS log_envios_sms (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  faturamento_id UUID NOT NULL,
  parcela_id UUID,
  numero_telefone VARCHAR(20) NOT NULL,
  mensagem TEXT,
  status status_envio_email DEFAULT 'pendente',
  id_mensagem_externa VARCHAR(255),
  enviado_em TIMESTAMP WITH TIME ZONE,
  entregue_em TIMESTAMP WITH TIME ZONE,
  erro_mensagem TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (faturamento_id) REFERENCES faturamentos(id) ON DELETE CASCADE,
  FOREIGN KEY (parcela_id) REFERENCES parcelas(id) ON DELETE SET NULL
);

-- Tabela de Cobranças
CREATE TABLE IF NOT EXISTS cobrancas (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL,
  faturamento_id UUID NOT NULL,
  parcela_id UUID,
  cliente_id UUID NOT NULL,
  numero_cobranca VARCHAR(50) UNIQUE NOT NULL,
  valor DECIMAL(12, 2) NOT NULL,
  data_cobranca DATE DEFAULT CURRENT_DATE,
  data_vencimento DATE,
  status VARCHAR(50) DEFAULT 'pendente',
  canal_envio canal_cobranca,
  forma_cobranca forma_cobranca,
  qr_code_pix TEXT,
  url_boleto VARCHAR(255),
  url_pagamento VARCHAR(255),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (faturamento_id) REFERENCES faturamentos(id) ON DELETE RESTRICT,
  FOREIGN KEY (parcela_id) REFERENCES parcelas(id) ON DELETE SET NULL,
  FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE RESTRICT
);

-- Tabela de Conciliação
CREATE TABLE IF NOT EXISTS conciliacao (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL,
  faturamento_id UUID,
  parcela_id UUID,
  cobranca_id UUID,
  tipo_pagamento forma_cobranca NOT NULL,
  valor DECIMAL(12, 2) NOT NULL,
  data_pagamento DATE NOT NULL,
  identificador_pagamento VARCHAR(255) UNIQUE,
  status status_conciliacao DEFAULT 'pendente',
  observacoes TEXT,
  conciliado_em TIMESTAMP WITH TIME ZONE,
  conciliado_por UUID,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (faturamento_id) REFERENCES faturamentos(id) ON DELETE SET NULL,
  FOREIGN KEY (parcela_id) REFERENCES parcelas(id) ON DELETE SET NULL,
  FOREIGN KEY (cobranca_id) REFERENCES cobrancas(id) ON DELETE SET NULL,
  FOREIGN KEY (conciliado_por) REFERENCES users(id) ON DELETE SET NULL
);

-- Tabela de Histórico de Pagamentos
CREATE TABLE IF NOT EXISTS historico_pagamentos (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  parcela_id UUID NOT NULL,
  valor_pago DECIMAL(12, 2) NOT NULL,
  data_pagamento DATE NOT NULL,
  forma_pagamento forma_cobranca,
  numero_documento VARCHAR(255),
  observacoes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (parcela_id) REFERENCES parcelas(id) ON DELETE CASCADE
);

-- ============================================================================
-- 4. ÍNDICES PARA PERFORMANCE
-- ============================================================================

-- Índices em users
CREATE INDEX idx_users_open_id ON users(open_id);
CREATE INDEX idx_users_email ON users(email);

-- Índices em empresas
CREATE INDEX idx_empresas_user_id ON empresas(user_id);
CREATE INDEX idx_empresas_cnpj ON empresas(cnpj);

-- Índices em clientes
CREATE INDEX idx_clientes_user_id ON clientes(user_id);
CREATE INDEX idx_clientes_cpf_cnpj ON clientes(cpf_cnpj);
CREATE INDEX idx_clientes_email ON clientes(email);
CREATE INDEX idx_clientes_ativo ON clientes(ativo);

-- Índices em faturamentos
CREATE INDEX idx_faturamentos_user_id ON faturamentos(user_id);
CREATE INDEX idx_faturamentos_cliente_id ON faturamentos(cliente_id);
CREATE INDEX idx_faturamentos_status ON faturamentos(status);
CREATE INDEX idx_faturamentos_data_vencimento ON faturamentos(data_vencimento);
CREATE INDEX idx_faturamentos_numero ON faturamentos(numero_faturamento);

-- Índices em parcelas
CREATE INDEX idx_parcelas_faturamento_id ON parcelas(faturamento_id);
CREATE INDEX idx_parcelas_status ON parcelas(status);
CREATE INDEX idx_parcelas_data_vencimento ON parcelas(data_vencimento);

-- Índices em cobrancas
CREATE INDEX idx_cobrancas_user_id ON cobrancas(user_id);
CREATE INDEX idx_cobrancas_cliente_id ON cobrancas(cliente_id);
CREATE INDEX idx_cobrancas_faturamento_id ON cobrancas(faturamento_id);
CREATE INDEX idx_cobrancas_status ON cobrancas(status);

-- Índices em conciliacao
CREATE INDEX idx_conciliacao_user_id ON conciliacao(user_id);
CREATE INDEX idx_conciliacao_faturamento_id ON conciliacao(faturamento_id);
CREATE INDEX idx_conciliacao_status ON conciliacao(status);
CREATE INDEX idx_conciliacao_identificador ON conciliacao(identificador_pagamento);

-- Índices em logs
CREATE INDEX idx_log_envios_email_faturamento_id ON log_envios_email(faturamento_id);
CREATE INDEX idx_log_envios_email_status ON log_envios_email(status);
CREATE INDEX idx_log_envios_whatsapp_faturamento_id ON log_envios_whatsapp(faturamento_id);
CREATE INDEX idx_log_envios_sms_faturamento_id ON log_envios_sms(faturamento_id);

-- ============================================================================
-- 5. POLÍTICAS DE ROW LEVEL SECURITY (RLS)
-- ============================================================================

-- Habilitar RLS em todas as tabelas
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE empresas ENABLE ROW LEVEL SECURITY;
ALTER TABLE configuracoes_smtp ENABLE ROW LEVEL SECURITY;
ALTER TABLE configuracoes_pix ENABLE ROW LEVEL SECURITY;
ALTER TABLE configuracoes_whatsapp ENABLE ROW LEVEL SECURITY;
ALTER TABLE configuracoes_sms ENABLE ROW LEVEL SECURITY;
ALTER TABLE configuracoes_boleto ENABLE ROW LEVEL SECURITY;
ALTER TABLE configuracoes_cartao ENABLE ROW LEVEL SECURITY;
ALTER TABLE configuracoes_banco ENABLE ROW LEVEL SECURITY;
ALTER TABLE configuracoes_formulario_cobranca ENABLE ROW LEVEL SECURITY;
ALTER TABLE servicos ENABLE ROW LEVEL SECURITY;
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE faturamentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE itens_faturamento ENABLE ROW LEVEL SECURITY;
ALTER TABLE parcelas ENABLE ROW LEVEL SECURITY;
ALTER TABLE log_envios_email ENABLE ROW LEVEL SECURITY;
ALTER TABLE log_envios_whatsapp ENABLE ROW LEVEL SECURITY;
ALTER TABLE log_envios_sms ENABLE ROW LEVEL SECURITY;
ALTER TABLE cobrancas ENABLE ROW LEVEL SECURITY;
ALTER TABLE conciliacao ENABLE ROW LEVEL SECURITY;
ALTER TABLE historico_pagamentos ENABLE ROW LEVEL SECURITY;

-- Políticas de RLS para usuários (apenas visualizar a si mesmo)
CREATE POLICY "users_select_self" ON users
  FOR SELECT USING (auth.uid()::text = open_id);

-- Políticas de RLS para empresas (apenas visualizar sua própria empresa)
CREATE POLICY "empresas_select_own" ON empresas
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "empresas_update_own" ON empresas
  FOR UPDATE USING (user_id = auth.uid());

CREATE POLICY "empresas_insert_own" ON empresas
  FOR INSERT WITH CHECK (user_id = auth.uid());

-- Políticas de RLS para configurações (apenas visualizar suas próprias configurações)
CREATE POLICY "configuracoes_smtp_select_own" ON configuracoes_smtp
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "configuracoes_smtp_update_own" ON configuracoes_smtp
  FOR UPDATE USING (user_id = auth.uid());

CREATE POLICY "configuracoes_smtp_insert_own" ON configuracoes_smtp
  FOR INSERT WITH CHECK (user_id = auth.uid());

-- Políticas similares para outras configurações
CREATE POLICY "configuracoes_pix_select_own" ON configuracoes_pix
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "configuracoes_pix_update_own" ON configuracoes_pix
  FOR UPDATE USING (user_id = auth.uid());

CREATE POLICY "configuracoes_pix_insert_own" ON configuracoes_pix
  FOR INSERT WITH CHECK (user_id = auth.uid());

-- Políticas para serviços
CREATE POLICY "servicos_select_own" ON servicos
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "servicos_insert_own" ON servicos
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "servicos_update_own" ON servicos
  FOR UPDATE USING (user_id = auth.uid());

CREATE POLICY "servicos_delete_own" ON servicos
  FOR DELETE USING (user_id = auth.uid());

-- Políticas para clientes
CREATE POLICY "clientes_select_own" ON clientes
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "clientes_insert_own" ON clientes
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "clientes_update_own" ON clientes
  FOR UPDATE USING (user_id = auth.uid());

CREATE POLICY "clientes_delete_own" ON clientes
  FOR DELETE USING (user_id = auth.uid());

-- Políticas para faturamentos
CREATE POLICY "faturamentos_select_own" ON faturamentos
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "faturamentos_insert_own" ON faturamentos
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "faturamentos_update_own" ON faturamentos
  FOR UPDATE USING (user_id = auth.uid());

CREATE POLICY "faturamentos_delete_own" ON faturamentos
  FOR DELETE USING (user_id = auth.uid());

-- Políticas para parcelas (através do faturamento)
CREATE POLICY "parcelas_select_own" ON parcelas
  FOR SELECT USING (
    faturamento_id IN (
      SELECT id FROM faturamentos WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "parcelas_insert_own" ON parcelas
  FOR INSERT WITH CHECK (
    faturamento_id IN (
      SELECT id FROM faturamentos WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "parcelas_update_own" ON parcelas
  FOR UPDATE USING (
    faturamento_id IN (
      SELECT id FROM faturamentos WHERE user_id = auth.uid()
    )
  );

-- Políticas para cobrancas
CREATE POLICY "cobrancas_select_own" ON cobrancas
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "cobrancas_insert_own" ON cobrancas
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "cobrancas_update_own" ON cobrancas
  FOR UPDATE USING (user_id = auth.uid());

-- Políticas para conciliacao
CREATE POLICY "conciliacao_select_own" ON conciliacao
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "conciliacao_insert_own" ON conciliacao
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "conciliacao_update_own" ON conciliacao
  FOR UPDATE USING (user_id = auth.uid());

-- ============================================================================
-- 6. FUNÇÕES E TRIGGERS
-- ============================================================================

-- Função para gerar número único de faturamento
CREATE OR REPLACE FUNCTION gerar_numero_faturamento()
RETURNS VARCHAR AS $$
DECLARE
  novo_numero VARCHAR;
  contador INTEGER;
BEGIN
  SELECT COUNT(*) + 1 INTO contador FROM faturamentos;
  novo_numero := 'FAT-' || TO_CHAR(CURRENT_DATE, 'YYYYMM') || '-' || LPAD(contador::text, 6, '0');
  RETURN novo_numero;
END;
$$ LANGUAGE plpgsql;

-- Função para gerar número único de cobrança
CREATE OR REPLACE FUNCTION gerar_numero_cobranca()
RETURNS VARCHAR AS $$
DECLARE
  novo_numero VARCHAR;
  contador INTEGER;
BEGIN
  SELECT COUNT(*) + 1 INTO contador FROM cobrancas;
  novo_numero := 'COB-' || TO_CHAR(CURRENT_DATE, 'YYYYMM') || '-' || LPAD(contador::text, 6, '0');
  RETURN novo_numero;
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar updated_at
CREATE OR REPLACE FUNCTION atualizar_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Aplicar trigger de updated_at em todas as tabelas
CREATE TRIGGER trigger_updated_at_users BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION atualizar_updated_at();

CREATE TRIGGER trigger_updated_at_empresas BEFORE UPDATE ON empresas
  FOR EACH ROW EXECUTE FUNCTION atualizar_updated_at();

CREATE TRIGGER trigger_updated_at_clientes BEFORE UPDATE ON clientes
  FOR EACH ROW EXECUTE FUNCTION atualizar_updated_at();

CREATE TRIGGER trigger_updated_at_faturamentos BEFORE UPDATE ON faturamentos
  FOR EACH ROW EXECUTE FUNCTION atualizar_updated_at();

CREATE TRIGGER trigger_updated_at_parcelas BEFORE UPDATE ON parcelas
  FOR EACH ROW EXECUTE FUNCTION atualizar_updated_at();

CREATE TRIGGER trigger_updated_at_cobrancas BEFORE UPDATE ON cobrancas
  FOR EACH ROW EXECUTE FUNCTION atualizar_updated_at();

CREATE TRIGGER trigger_updated_at_conciliacao BEFORE UPDATE ON conciliacao
  FOR EACH ROW EXECUTE FUNCTION atualizar_updated_at();

-- Trigger para gerar número de faturamento automaticamente
CREATE TRIGGER trigger_gerar_numero_faturamento BEFORE INSERT ON faturamentos
  FOR EACH ROW
  WHEN (NEW.numero_faturamento IS NULL)
  EXECUTE FUNCTION gerar_numero_faturamento();

-- Trigger para gerar número de cobrança automaticamente
CREATE TRIGGER trigger_gerar_numero_cobranca BEFORE INSERT ON cobrancas
  FOR EACH ROW
  WHEN (NEW.numero_cobranca IS NULL)
  EXECUTE FUNCTION gerar_numero_cobranca();

-- ============================================================================
-- 7. VIEWS ÚTEIS
-- ============================================================================

-- View: Contas a Receber (Resumo)
CREATE OR REPLACE VIEW vw_contas_receber AS
SELECT
  f.id,
  f.numero_faturamento,
  c.nome AS cliente_nome,
  c.cpf_cnpj,
  f.valor_liquido,
  p.numero_parcela,
  p.valor,
  p.data_vencimento,
  p.status,
  CASE
    WHEN p.data_vencimento < CURRENT_DATE AND p.status = 'pendente' THEN 'vencido'
    WHEN p.data_vencimento >= CURRENT_DATE AND p.status = 'pendente' THEN 'a_vencer'
    ELSE p.status
  END AS status_calculado,
  f.created_at,
  f.user_id
FROM faturamentos f
JOIN clientes c ON f.cliente_id = c.id
LEFT JOIN parcelas p ON f.id = p.faturamento_id
WHERE f.status != 'cancelado';

-- View: Cobranças Pendentes
CREATE OR REPLACE VIEW vw_cobrancas_pendentes AS
SELECT
  c.id,
  c.numero_cobranca,
  cl.nome AS cliente_nome,
  cl.cpf_cnpj,
  c.valor,
  c.data_vencimento,
  c.status,
  c.canal_envio,
  c.forma_cobranca,
  c.user_id
FROM cobrancas c
JOIN clientes cl ON c.cliente_id = cl.id
WHERE c.status IN ('pendente', 'enviada');

-- View: Resumo de Faturamentos por Cliente
CREATE OR REPLACE VIEW vw_resumo_cliente AS
SELECT
  c.id,
  c.nome,
  c.cpf_cnpj,
  COUNT(f.id) AS total_faturamentos,
  SUM(f.valor_liquido) AS valor_total,
  SUM(CASE WHEN f.status = 'pago' THEN f.valor_liquido ELSE 0 END) AS valor_pago,
  SUM(CASE WHEN f.status IN ('pendente', 'vencido') THEN f.valor_liquido ELSE 0 END) AS valor_pendente,
  c.user_id
FROM clientes c
LEFT JOIN faturamentos f ON c.id = f.cliente_id
GROUP BY c.id, c.nome, c.cpf_cnpj, c.user_id;

-- ============================================================================
-- 8. COMENTÁRIOS E DOCUMENTAÇÃO
-- ============================================================================

COMMENT ON TABLE users IS 'Tabela de usuários (Tenants do sistema)';
COMMENT ON TABLE empresas IS 'Configurações e dados da empresa do usuário';
COMMENT ON TABLE clientes IS 'Cadastro de clientes com configurações de cobrança';
COMMENT ON TABLE faturamentos IS 'Faturamentos emitidos para clientes';
COMMENT ON TABLE parcelas IS 'Parcelas de faturamentos (para pagamentos parcelados)';
COMMENT ON TABLE cobrancas IS 'Cobranças enviadas aos clientes';
COMMENT ON TABLE conciliacao IS 'Conciliação de pagamentos recebidos';

-- ============================================================================
-- FIM DO SCHEMA
-- ============================================================================
