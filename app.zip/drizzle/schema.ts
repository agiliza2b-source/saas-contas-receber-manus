import { pgTable, serial, text, varchar, timestamp, integer, pgEnum } from "drizzle-orm/pg-core";

/**
 * Enums para PostgreSQL
 */
export const faturamentoStatusEnum = pgEnum("faturamento_status", ["pendente", "parcial", "pago", "vencido", "cancelado"]);
export const tipoParcelaEnum = pgEnum("tipo_parcela", ["unica", "parcelado", "recorrente"]);
export const parcelaStatusEnum = pgEnum("parcela_status", ["pendente", "pago", "vencido", "cancelada"]);
export const canalCobrancaEnum = pgEnum("canal_cobranca", ["email", "whatsapp", "sms", "pix"]);
export const statusCobrancaEnum = pgEnum("status_cobranca", ["pendente", "enviada", "recebida", "lida", "paga", "cancelada"]);
export const statusEnvioEmailEnum = pgEnum("status_envio_email", ["enviado", "falha", "bounce", "recebido", "lido"]);
export const statusConciliacaoEnum = pgEnum("status_conciliacao", ["pendente", "confirmada", "rejeitada"]);

/**
 * Core user table backing auth flow.
 */
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  openId: varchar("open_id", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("login_method", { length: 64 }),
  role: varchar("role", { length: 50 }).default("user").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  lastSignedIn: timestamp("last_signed_in", { withTimezone: true }).defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Tabela de Servicos
 */
export const servicos = pgTable("servicos", {
  id: serial("id").primaryKey(),
  descricao: varchar("descricao", { length: 255 }).notNull(),
  valor: varchar("valor", { length: 20 }).notNull(),
  ativo: integer("ativo").default(1),
  criadoEm: timestamp("criado_em", { withTimezone: true }).defaultNow().notNull(),
  atualizadoEm: timestamp("atualizado_em", { withTimezone: true }).defaultNow().notNull(),
});

export type Servico = typeof servicos.$inferSelect;
export type InsertServico = typeof servicos.$inferInsert;

/**
 * Tabela de Clientes
 */
export const clientes = pgTable("clientes", {
  id: serial("id").primaryKey(),
  nomeCompleto: varchar("nome_completo", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  cpfCnpj: varchar("cpf_cnpj", { length: 18 }).notNull().unique(),
  telefone: varchar("telefone", { length: 20 }),
  endereco: text("endereco"),
  cep: varchar("cep", { length: 10 }),
  cidade: varchar("cidade", { length: 100 }),
  estado: varchar("estado", { length: 2 }),
  formasFaturamento: text("formas_faturamento"),
  ativo: integer("ativo").default(1),
  criadoEm: timestamp("criado_em", { withTimezone: true }).defaultNow().notNull(),
  atualizadoEm: timestamp("atualizado_em", { withTimezone: true }).defaultNow().notNull(),
});

export type Cliente = typeof clientes.$inferSelect;
export type InsertCliente = typeof clientes.$inferInsert;

/**
 * Tabela de Faturamentos
 */
export const faturamentos = pgTable("faturamentos", {
  id: serial("id").primaryKey(),
  clienteId: integer("cliente_id").notNull().references(() => clientes.id, { onDelete: 'cascade' }),
  numero: varchar("numero", { length: 50 }).notNull().unique(),
  descricao: text("descricao"),
  dataEmissao: timestamp("data_emissao", { withTimezone: true }).defaultNow().notNull(),
  dataVencimento: timestamp("data_vencimento", { withTimezone: true }).notNull(),
  valorTotal: varchar("valor_total", { length: 20 }).notNull(),
  status: faturamentoStatusEnum("status").default("pendente"),
  tipoParcela: tipoParcelaEnum("tipo_parcela").default("unica"),
  quantidadeParcelas: integer("quantidade_parcelas").default(1),
  jurosAoMes: varchar("juros_ao_mes", { length: 10 }),
  desconto: varchar("desconto", { length: 20 }),
  observacoes: text("observacoes"),
  ativo: integer("ativo").default(1),
  criadoEm: timestamp("criado_em", { withTimezone: true }).defaultNow().notNull(),
  atualizadoEm: timestamp("atualizado_em", { withTimezone: true }).defaultNow().notNull(),
});

export type Faturamento = typeof faturamentos.$inferSelect;
export type InsertFaturamento = typeof faturamentos.$inferInsert;

/**
 * Tabela de Parcelas
 */
export const parcelas = pgTable("parcelas", {
  id: serial("id").primaryKey(),
  faturamentoId: integer("faturamento_id").notNull().references(() => faturamentos.id, { onDelete: 'cascade' }),
  numeroParcela: integer("numero_parcela").notNull(),
  dataVencimento: timestamp("data_vencimento", { withTimezone: true }).notNull(),
  valor: varchar("valor", { length: 20 }).notNull(),
  juros: varchar("juros", { length: 20 }).default("0"),
  multa: varchar("multa", { length: 20 }).default("0"),
  desconto: varchar("desconto", { length: 20 }).default("0"),
  valorPago: varchar("valor_pago", { length: 20 }).default("0"),
  dataPagamento: timestamp("data_pagamento", { withTimezone: true }),
  formaPagamento: varchar("forma_pagamento", { length: 50 }),
  status: parcelaStatusEnum("status").default("pendente"),
  chavePix: varchar("chave_pix", { length: 255 }),
  codigoBarras: varchar("codigo_barras", { length: 50 }),
  ativo: integer("ativo").default(1),
  criadoEm: timestamp("criado_em", { withTimezone: true }).defaultNow().notNull(),
  atualizadoEm: timestamp("atualizado_em", { withTimezone: true }).defaultNow().notNull(),
});

export type Parcela = typeof parcelas.$inferSelect;
export type InsertParcela = typeof parcelas.$inferInsert;

/**
 * Tabela de Itens de Faturamento
 */
export const itensFaturamento = pgTable("itens_faturamento", {
  id: serial("id").primaryKey(),
  faturamentoId: integer("faturamento_id").notNull().references(() => faturamentos.id, { onDelete: 'cascade' }),
  descricao: varchar("descricao", { length: 255 }).notNull(),
  quantidade: varchar("quantidade", { length: 20 }).notNull(),
  valorUnitario: varchar("valor_unitario", { length: 20 }).notNull(),
  valorTotal: varchar("valor_total", { length: 20 }).notNull(),
  ativo: integer("ativo").default(1),
  criadoEm: timestamp("criado_em", { withTimezone: true }).defaultNow().notNull(),
  atualizadoEm: timestamp("atualizado_em", { withTimezone: true }).defaultNow().notNull(),
});

export type ItemFaturamento = typeof itensFaturamento.$inferSelect;
export type InsertItemFaturamento = typeof itensFaturamento.$inferInsert;

/**
 * Tabela de Cobranças
 */
export const cobrancas = pgTable("cobrancas", {
  id: serial("id").primaryKey(),
  parcelaId: integer("parcela_id").notNull().references(() => parcelas.id, { onDelete: 'cascade' }),
  faturamentoId: integer("faturamento_id").notNull().references(() => faturamentos.id, { onDelete: 'cascade' }),
  clienteId: integer("cliente_id").notNull().references(() => clientes.id, { onDelete: 'cascade' }),
  status: statusCobrancaEnum("status").default("pendente"),
  dataEnvio: timestamp("data_envio", { withTimezone: true }),
  dataRecebimento: timestamp("data_recebimento", { withTimezone: true }),
  dataLeitura: timestamp("data_leitura", { withTimezone: true }),
  canal: canalCobrancaEnum("canal").default("email"),
  tentativas: integer("tentativas").default(0),
  proximaTentativa: timestamp("proxima_tentativa", { withTimezone: true }),
  observacoes: text("observacoes"),
  ativo: integer("ativo").default(1),
  criadoEm: timestamp("criado_em", { withTimezone: true }).defaultNow().notNull(),
  atualizadoEm: timestamp("atualizado_em", { withTimezone: true }).defaultNow().notNull(),
});

export type Cobranca = typeof cobrancas.$inferSelect;
export type InsertCobranca = typeof cobrancas.$inferInsert;

/**
 * Tabela de Logs de Email
 */
export const logsEmail = pgTable("logs_email", {
  id: serial("id").primaryKey(),
  cobrancaId: integer("cobranca_id").references(() => cobrancas.id, { onDelete: 'set null' }),
  faturamentoId: integer("faturamento_id").references(() => faturamentos.id, { onDelete: 'set null' }),
  parcelaId: integer("parcela_id").references(() => parcelas.id, { onDelete: 'set null' }),
  clienteId: integer("cliente_id").references(() => clientes.id, { onDelete: 'set null' }),
  emailDestino: varchar("email_destino", { length: 320 }).notNull(),
  assunto: varchar("assunto", { length: 255 }).notNull(),
  corpo: text("corpo"),
  status: statusEnvioEmailEnum("status").default("enviado"),
  mensagemErro: text("mensagem_erro"),
  dataEnvio: timestamp("data_envio", { withTimezone: true }).defaultNow().notNull(),
  dataRecebimento: timestamp("data_recebimento", { withTimezone: true }),
  dataLeitura: timestamp("data_leitura", { withTimezone: true }),
  criadoEm: timestamp("criado_em", { withTimezone: true }).defaultNow().notNull(),
});

export type LogEmail = typeof logsEmail.$inferSelect;
export type InsertLogEmail = typeof logsEmail.$inferInsert;

/**
 * Tabela de Conciliação de Pagamentos
 */
export const conciliacao = pgTable("conciliacao", {
  id: serial("id").primaryKey(),
  parcelaId: integer("parcela_id").notNull().references(() => parcelas.id, { onDelete: 'cascade' }),
  faturamentoId: integer("faturamento_id").notNull().references(() => faturamentos.id, { onDelete: 'cascade' }),
  clienteId: integer("cliente_id").notNull().references(() => clientes.id, { onDelete: 'cascade' }),
  valor: varchar("valor", { length: 20 }).notNull(),
  dataRecebimento: timestamp("data_recebimento", { withTimezone: true }).notNull(),
  formaPagamento: varchar("forma_pagamento", { length: 50 }).notNull(),
  referencia: varchar("referencia", { length: 255 }),
  descricao: text("descricao"),
  status: statusConciliacaoEnum("status").default("pendente"),
  observacoes: text("observacoes"),
  criadoEm: timestamp("criado_em", { withTimezone: true }).defaultNow().notNull(),
  atualizadoEm: timestamp("atualizado_em", { withTimezone: true }).defaultNow().notNull(),
});

export type Conciliacao = typeof conciliacao.$inferSelect;
export type InsertConciliacao = typeof conciliacao.$inferInsert;

/**
 * Tabela de Histórico de Pagamentos
 */
export const historicoPagamentos = pgTable("historico_pagamentos", {
  id: serial("id").primaryKey(),
  parcelaId: integer("parcela_id").notNull().references(() => parcelas.id, { onDelete: 'cascade' }),
  faturamentoId: integer("faturamento_id").notNull().references(() => faturamentos.id, { onDelete: 'cascade' }),
  clienteId: integer("cliente_id").notNull().references(() => clientes.id, { onDelete: 'cascade' }),
  valorPago: varchar("valor_pago", { length: 20 }).notNull(),
  dataPagamento: timestamp("data_pagamento", { withTimezone: true }).notNull(),
  formaPagamento: varchar("forma_pagamento", { length: 50 }).notNull(),
  referencia: varchar("referencia", { length: 255 }),
  jurosAplicados: varchar("juros_aplicados", { length: 20 }).default("0"),
  multaAplicada: varchar("multa_aplicada", { length: 20 }).default("0"),
  descontoAplicado: varchar("desconto_aplicado", { length: 20 }).default("0"),
  observacoes: text("observacoes"),
  criadoEm: timestamp("criado_em", { withTimezone: true }).defaultNow().notNull(),
});

export type HistoricoPagamento = typeof historicoPagamentos.$inferSelect;
export type InsertHistoricoPagamento = typeof historicoPagamentos.$inferInsert;
