import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { clientesRouter } from "./routers/clientes.router";
import { faturamentoRouter } from "./routers/faturamento.router";
import { cobrancaRouter } from "./routers/cobranca.router";
import { configuracaoRouter } from "./routers/configuracao.router";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  clientes: clientesRouter,
  faturamento: faturamentoRouter,
  cobranca: cobrancaRouter,
  configuracao: configuracaoRouter,
});

export type AppRouter = typeof appRouter;
